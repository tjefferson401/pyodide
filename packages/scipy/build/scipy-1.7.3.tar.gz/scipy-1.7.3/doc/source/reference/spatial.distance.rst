.. automodule:: scipy.spatial.distance
   :no-members:
   :no-inherited-members:
   :no-special-members:
