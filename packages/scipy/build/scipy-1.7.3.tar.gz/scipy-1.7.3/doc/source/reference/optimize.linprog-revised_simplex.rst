.. _optimize.linprog-revised_simplex:

linprog(method='revised simplex')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.linprog
   :impl: scipy.optimize._linprog._linprog_rs_doc
   :method: revised_simplex
