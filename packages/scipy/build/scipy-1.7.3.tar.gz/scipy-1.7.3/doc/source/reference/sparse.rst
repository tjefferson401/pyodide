.. automodule:: scipy.sparse
   :no-members:
   :no-inherited-members:
   :no-special-members:
